<?php
$EmailFrom = "$theyouthapproachinitiative.org";
$EmailTo = "theyouthapproach@live.com";
$subject = "WEBSITE VISITOR'S MESSAGE.";
$name = Trim(stripslashes($_POST['name'])); 
$email = Trim(stripslashes($_POST['email'])); 
$message = Trim(stripslashes($_POST['cf_message'])); 

// prepare email body text
$body = "";
$body .= "Name: ";
$body .= $name;
$body .= "r\n";
$body .= "Email: ";
$body .= $email;
$body .= "r\n";
$body .= "Message: ";
$body .= $message;
$body .= "r\n";

// validation
$validationOK=true;
if (!$validationOK) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
    exit;
}

// send email 
$success = mail($EmailTo, $subject, $body, "From: <$EmailFrom>");

// redirect to success page 
if ($success){
header("Location: ../about-us.php");
}
else{
header("Location: ../error.html");
}
?>