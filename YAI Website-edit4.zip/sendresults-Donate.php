<?php
$EmailFrom = "$theyouthapproachinitiative.org";
$EmailTo = "emkingmediainc@gmail.com";
$subject = "ONLINE APPLICATION TO DONATE.";
$name = Trim(stripslashes($_POST['name']));
$nationality = Trim(stripslashes($_POST['nationality']));  
$email = Trim(stripslashes($_POST['email'])); 
$donation = Trim(stripslashes($_POST['donation']));
$designation = Trim(stripslashes($_POST['designation']));
$duration = Trim(stripslashes($_POST['duration']));
$message = Trim(stripslashes($_POST['message'])); 

// prepare email body text
$body = "";
$body .= "Applicants Full Name: ";
$body .= $name;
$body .= "r\n";
$body .= "Applicants Nationality: ";
$body .= $nationality;
$body .= "r\n";
$body .= "Applicants  E-mail: ";
$body .= $email;
$body .= "r\n";
$body .= "Donation Amount?: ";
$body .= $donation;
$body .= "r\n";
$body .= "Donating to: ";
$body .= $designation;
$body .= "r\n";
$body .= "Additional details: ";
$body .= $details;
$body .= "r\n";

// validation
$validationOK=true;
if (!$validationOK) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
    exit;
}

// send email 
$success = mail($EmailTo, $subject, $body, "From: <$EmailFrom>");

// redirect to success page 
if ($success){
header("Location: ../Thank-You.php");
}
else{
header("Location: ../error.html");
}
?>