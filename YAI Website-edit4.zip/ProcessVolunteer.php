<?php 
$toemail = 'emkingmediainc@gmail.com';
$name = $_POST['name'];
$nationality = $_POST['nationality'];
$email = $_POST['email'];
$vchoice = $_POST['vchoice'];
$vdetails = $_POST['vdetails'];
$designation = $_POST['designation'];
$message = $_POST['message'];
if(mail($toemail, 'Subject', $message, 'From: ' . $email)) {
	echo 'Your info was sent successfully.';
} else {
	echo 'There was a problem sending your details.';
}
?>