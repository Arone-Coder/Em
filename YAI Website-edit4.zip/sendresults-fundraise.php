<?php
$EmailFrom = "$theyouthapproachinitiative.org";
$EmailTo = "emkingmediainc@gmail.com";
$subject = "ONLINE FUNDRAISER APPLICATION.";
$name = Trim(stripslashes($_POST['name']));
$nationality = Trim(stripslashes($_POST['nationality']));  
$email = Trim(stripslashes($_POST['email'])); 
$occupation = Trim(stripslashes($_POST['occupation']));
$fundraisekind = Trim(stripslashes($_POST['fundraisekind']));
$estimatedoutcome = Trim(stripslashes($_POST['estimatedoutcome']));
$estimatedcost = Trim(stripslashes($_POST['estimatedcost']));
$yourpladge = Trim(stripslashes($_POST['yourpladge']));
$message = Trim(stripslashes($_POST['message'])); 

// prepare email body text
$body = "";
$body .= "Applicants Full Name: ";
$body .= $name;
$body .= "r\n";
$body .= "Applicants Nationality: ";
$body .= $nationality;
$body .= "r\n";
$body .= "Applicants  E-mail: ";
$body .= $email;
$body .= "r\n";
$body .= "Applicants Occupation: ";
$body .= $occupation;
$body .= "r\n";
$body .= "The Kind of Fundraise: ";
$body .= $fundraisekind;
$body .= "r\n";
$body .= "The Estimated outcome: ";
$body .= $estimatedoutcome;
$body .= "r\n";
$body .= "Applicants  pledge from the fundraise: ";
$body .= $yourpladge;
$body .= "r\n";
$body .= "Additional details: ";
$body .= $details;
$body .= "r\n";

// validation
$validationOK=true;
if (!$validationOK) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
    exit;
}

// send email 
$success = mail($EmailTo, $subject, $body, "From: <$EmailFrom>");

// redirect to success page 
if ($success){
header("Location: ../Thank-You.php");
}
else{
header("Location: ../error.html");
}
?>