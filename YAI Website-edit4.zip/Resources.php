<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->
<head>
	<!-- Basic Meta Tags -->
 <meta charset="utf-8">
  <title>Youth & Young People's Resources   |    THE YOUTH APPROACH INITIATIVE</title>
  <meta name="keywords" content="Youth & Young People's Resources, Sex, Birth controls, Reproductive methods, Sexual diseases, Love & Relationships">
<meta name="description" content="We are a Non-Profit, non-government organization operating at the grassroot level, serving humanity with an objective of helping people Stay Safe, healthy and living well">
  
<meta property="og:title" content="Check out Qustions & Answers about Sex, Love, Relationship, Diseases">
<meta property="og:description" content="Detailed information that is crucial & helpful in helping you Stay Safe, Healthy & Living well">
<meta property="og:image" content="http://theyouthapproachintiative.org/img/Resource.png" />
<link rel="canonical" href="http://theyouthapproachintiative.org/Resources.php">
<link rel="shortlink" href="http://theyouthapproachintiative.org/">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="img/favicon.png" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
  <!-- Header -->
  <header id="header">
      <div class="row t-container">

        <!-- Logo -->
       <br/> <div class="span3">
            
        </div>
        <img src="img/yai_banner.jpg" alt="banner">
        
<div class="row">
<div class="row">        
<div class="span9">
        <div class="row space10"></div>
             <nav id="nav" role="navigation" name="nav">
               	<a href="#nav" title="Show navigation">Show navigation</a>
	            <a href="#" title="Hide navigation">Hide navigation</a>
	            <ul class="clearfix">
	           	<li><a href="index.php" title=""><span><strong>HOME</strong></span></a>
  			      <ul> <!-- Submenu -->
            <li><a href="Gallery-Videos.php" title="" target="_blank">Videos Gallery</a></li>
                      <li><a href="Gallery-Photos.php" title="">Photos Gallery</a></li>
  		         </ul> <!-- End Submenu -->
                <li><a href="About-us-info.php" title=""><span><strong>ABOUT US</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Who-we-are.php" title="">Who We Are</a></li>
                      <li><a href="Background.php" title="">Our Background</a></li>
                      <li><a href="What-we-do.php" title="">What we do</a></li>
                      <li><a href="Mission.php" title="">Our Mission</a></li>
                      <li><a href="Vision.php" title="">Our Vision</a></li>
                      <li><a href="Objectives.php" title="">Our Objectives</a></li>
                      <li><a href="Policies.php" title="">Our Policies</a></li>
                      <li><a href="Values.php" title="">Our Values</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Programs-Listing.php" title=""><span><strong>OUR PROGRAMS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Program-Staying-Safe.php" title="">Staying Safe</a></li>
                      <li><a href="Program-Staying-Healthy.php" title="">Staying Healthy</a></li>
                      <li><a href="Program-Living-Well.php" title="">Living Well/ Good</a></li>
                      <li><a href="Program-Education.php" title="">Education</a></li>
                    <li><a href="Program-Cultural-Exchange.php" title="">Cultural Exchange</a></li>
                    <li><a href="Program-TheYAI-Aid.php" title="">The Youth Approach Aid</a></li>
                      <li><a href="Resources.php" title="">Youth Resources</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Projects-Listing.php" title=""><span><strong>OUR PROJECTS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Project-Stay-Safe-and-Healthy-Tours.php" title="">The Stay safe & Healthy Tours</a></li>
                      <li><a href="Project-The-Youth-Empowerment-Forum.php" title="">The Empowerment Forum</a></li>
                    <li><a href="Project-Debates-and-Dialogues.php" title="">Debates & Dialogues</a></li>
                      <li><a href="TheYAI-Aid-Agriculture.php" title="">The YAI Aid-Agriculture</a></li>
                      <li><a href="TheYAI-Aid-Education.php" title="">The YAI Aid-Education</a></li>
                      <li><a href="TheYAI-Aid-Food.php" title="">The YAI Aid-Food4Hunger</a></li>
                      <li><a href="TheYAI-Aid-Medical.php" title="">The YAI Aid-Health & Medic</a></li>
                      <li><a href="TheYAI-Aid-SACCO.php" title="">The YAI-Aid-SACCO</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Structure-Listing.php" title=""><span><strong>OUR STRUCTURES</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Structure-Governance.php" title="">Governance</a></li>
                      <li><a href="Structure-Gov-EXCOM.php" title="">The Executive Committee</a></li>
                      <li><a href="Structure-Secretariate.php" title="">The Secretariat</a></li>
                      <li><a href="Structure-Accountability.php" title="">Accountability</a></li>
                      <li><a href="Structure-Monitoring-and-Evaluation.php" title="">Monitoring & Evaluation</a></li>
                      <li><a href="Structure-Sustainability.php" title="">Sustainability</a></li>
                      <li><a href="Structure-The-YAI-RPP.php" title="">Referral Partnership</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Get-Involved-Listing.php" title=""><span><strong>GET INVOLVED</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Get-Involved-Donate.php" title="">Donate</a></li>
                      <li><a href="Get-Involved-Fundraise.php" title="">Fundraise</a></li>
                      <li><a href="Get-Involved-Join-RPP.php" title="">Join our RPP</a></li>
                      <li><a href="Duties-Secretariate-Volunteers.php" title="">Volunteer</a></li>
                      <li><a href="Get-Involved-Contract-us.php" title="">Contract Us</a></li>
                      <li><a href="Get-Involved-Organise-Event.php" title="">Organise Event</a></li>
                      <li><a href="Get-Involved-Contact-us.php" title="">Contact Us</a></li>
  		         </ul> <!-- End Submenu --> 
               </li> 
	           </ul>
          </nav>
         </div> 
         </div> 
      </div>  
       <div class="row space40"></div>
  </div> 
</header><!-- Header End -->

<!-- Titlebar
================================================== -->
<section id="titlebar">
	<!-- Container -->
	<div class="container">
		<div class="eight columns">
			<h2 align="center"><strong><u>THE YOUTH APPROACH RESOURCES CENTER</u></strong></h2>
            </div>
          </div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">
<div class="row">
		</div>
           <div class="row space10"></div>
      <div class="row">
        <div class="span9">
              <p align="center"><strong>We have put together information that is crucial & helpful in helping you Stay safe, Healthy & Living well</strong></p>
            </div>
            </div>  
  
          <div class="row space30"></div>  

          <div class="row">
            <div class="span4">
              <h3><strong><u>Social</u></strong></h3> 
              <ul class="list-a">
                <li>Love & Relationships <a href="Resources-Relationships.php">(Know)</a></li>
                <li>Sex and Intimacy <a href="#">(See)</a></li>
                <li>Good and Bad about Sex <a href="#">(Read)</a></li>
                <li>Exploring your sexuality <a href="#">(Know)</a></li>
                <li>Preparing for Sex <a href="#">(See)</a></li>
                <li>Age of Consent <a href="#">(Find out)</a></li>
                <li>Protected & Unprotected Sex <a href="#">(See)</a></li>
                <li>Sex with under age (Defilement) <a href="#">(know)</a></li>
                <li>Sex with Prostitute <a href="#">(Know)</a></li>
                <li>Sex with fellow male or female <a href="#">(Know)</a></li>
              </ul>   
            </div>
   
            <div class="row">
            <div class="span4">
              <h3><strong><u>Sexual Diseases</u></strong></h3> 
              <ul class="list-a">
                <li>HIV/AIDS-(STD) <a href="Resources-HIV-AIDS.php">(Know)</a></li>
                <li>Gonorrhea-(STI) <a href="#">(Know)</a></li>
                <li>Hepatitis-(STI) <a href="#">(Know)</a></li>
                <li>Herpes-(STI) <a href="#">(Know)</a></li>
                <li>HPV (human papilloma virus)-(STI) <a href="#">(Know)</a></li>
                <li>chlamydia-(STI) <a href="#">(Know)</a></li>
                <strong>Know about:</strong><br/>
                <li>Antiretroviral (ARV) <a href="Resources-ARV.php">(Know)</a></li>
                <li>HIV testing and counselling (HTC) <a href="Resources-HIV-AIDS.php">(Know)</a></li>
                <li>Stigma <a href="#">(Know)</a></li> 
              </ul>   
            </div>
            
            <div class="row">
            <div class="span4"> 
              <h3><strong><u>Birth Control methods</u></strong></h3>
              <ul class="list-a">
                <li>Emergency Contraceptive Pills <a href="Resources-ECPs.php">(Know)</a></li>
                <li>Progestin Only Pills (POPs) <a href="Resources-POPs.php">(Know)</a></li>
                <li>Intrauterine Devices (IUDs) <a href="Resources-IUDs.php">(Know)</a></li>
                <li>Diaphragm <a href="Resources-Diaphragm.php">(Know) </a></li>
                <li>Progestine Only Injectables <a href="Resources-Progestine-Only-Injectables.php">(Know)</a></li>
                <li>Spermicides <a href="Resources-Spermicides.php">(Know)</a></li>
                <li>Lactational Amenorrhea Method <a href="Resources-Lactational-Amenorrhea-Method.php">(Know)</a></li>
                <li>Female Fertilization <a href="Resources-Female-Fertilization.php">(Know)</a></li>
                <li>Combined Oral Contraceptives <a href="Resources-Combined-Oral-Contraceptives.php">(Know)</a></li>
                <li>Combined Injectable Contraceptives <a href="Resources-Combined-Injectable-Contraceptives.php">(Know)</a></li>
              </ul>   
            </div>
            </div>
          </div> 
          </div>
          <p><div class="search-box">
              <div><a href="http://www.theyouthapproachinitiative.org" class="search-icon"><i class="icon-search"></i></a>
                <input class="search" name="" value="Find by Search">
              </div></div>
              <br/>
              <br/>
              <strong>All the information was provided by Professionally qualified, practicing doctors and medical experts in their respective fields, and are also part of The YAI RPP</strong>
         <hr> 
    <div align="right"><a href="#"><img src="img/Back to Top.png" alt="Back to the Top of Page" class="icon-align-right" longdesc="http://www.theyouthapproachinitiative.org"></a></div>
      <div class="space10"></div>
    <h3><strong>Get in touch with us</strong></h3>
            <div>We like hearing from everyone that comes across anything to do with us. Please, it will be so grateful to hear from you. Write us a message below, and we shall get back to you as soon as we recieve your post. Thank you </div>
                                   
          <div class="row space50"></div>  
        </div>
      </div>
  <!-- Content End -->
  
 <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="span5">
        <h3>Contact Us</h3>
        <div>         
          <form class="form-main" name="ajax-form" id="ajax-form" action="process.php" method="post">
            <div id="ajaxsuccess">E-mail was successfully sent.</div> 
            <div class="error" id="err-name">Please enter name</div>
            <input name="name" id="name" type="text" value="Name" onfocus="if(this.value == 'Name') this.value='';" onblur="if(this.value == '') this.value='Name';">
            
            <div class="error" id="err-email">Please enter e-mail</div>
		        <div class="error" id="err-emailvld">E-mail is not a valid format</div>
            <input  name="email" id="email" type="text" value="E-mail" onfocus="if(this.value == 'E-mail') this.value='';" onblur="if(this.value == '') this.value='E-mail';">

            <div class="error" id="err-message">Please enter message</div>
            <textarea  name="message" id="message" type="text" value="Message"onfocus="if(this.value == 'Message') this.value='';" onblur="if(this.value == '') this.value='Message';">Message</textarea><br>
            <div>
            	<div class="error" id="err-form">There was a problem validating the form please check!</div>
            	<div class="error" id="err-timedout">The connection to the server timed out!</div>
            	<div class="error" id="err-state"></div>
            </div>
            <button id="send" class="btn f-right">Send Message <i class="icon-ok"></i></button>
          </form>
        </div>
        </div>
        <div class="span3 offset3">
          <h3>Address</h3>
          Entebbe Road, Kampala<br>
          P. O. Box 24984, Kampala (U)<br>
          KAMPALA UGANDA<br>
          <br>
          <i class="icon-phone"></i> : +256-752-848120<br>
          <i class="icon-envelope"></i>: <a href="mailto:theyouthapproach@live.com">theyouthapproach@live.com</a>			<br>
          <i class="icon-home"></i>: <a href="#" target="_blank">theyouthapproachinitiative.org</a>
          <br/><strong>JOIN US ON SOCIAL MEDIA:</strong> <br/><a href="http://www.twitter.com/theyai" target="_blank"><img src="img/Twitter.png" alt="Twitter icon" class="icon-twitter" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>
                   
<a href="http://www.facebook.com/theyouthapproachinitiative"><img src="img/facebook.png" alt="Support link to facebook Campaign" class="icon-facebook" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>     

<a href="http://www.instagram.com/theyai"><img src="img/Instagram.png" alt="link to Campaign on Instagram" class="icon-facebook" longdesc="http://http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a> 
          <div class="row space10"></div>   
          </div>
        <div class="span3 offset3">
          <h3><u>OUR WEBSITE CONTENT POLICY</u></h3>
          <div align="justify">All the information given here is correct at the time of publication.<br>
          It is in our policy to constantly update our site but we shall not be responsible for changes in the information published at any given time. Our Content is subject to changes and adjustments at anytime without prior notice.<br>
          </div>
          </div>
      </div>
      
      <div class="row space20"></div>
      <div class="row">
        <div class="span6">
          <div class="logo-footer">
            Powered by: <a href="http://web.emkingmedia.com" target="_blank">Emking Web & Online Technologies inc</a>
          </div>                       
        </div>
        <div class="span6 right">
          &copy; 2020. The Youth Approach Initiative.
        </div>
      </div>

    </div>
  </footer>
  <!-- Footer End -->

  <!-- JavaScripts -->
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" defer src="js/jquery.flexslider.js"></script>
<body>
</body>
</html>