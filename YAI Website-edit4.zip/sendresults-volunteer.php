<?php
$EmailFrom = "$theyouthapproachinitiative.org";
$EmailTo = "emkingmediainc@gmail.com";
$subject = "ONLINE VOLUNTEER APPLICATION.";
$name = Trim(stripslashes($_POST['name']));
$nationality = Trim(stripslashes($_POST['nationality']));  
$email = Trim(stripslashes($_POST['email'])); 
$vchoice = Trim(stripslashes($_POST['vchoice']));
$vdetails = Trim(stripslashes($_POST['vdetails']));
$designation = Trim(stripslashes($_POST['designation']));
$message = Trim(stripslashes($_POST['message'])); 

// prepare email body text
$body = "";
$body .= "Your Full Name: ";
$body .= $name;
$body .= "r\n";
$body .= "Nationality: ";
$body .= $nationality;
$body .= "r\n";
$body .= "Your E-mail: ";
$body .= $email;
$body .= "r\n";
$body .= "How do wish to Volunteer?: ";
$body .= $vchoice;
$body .= "r\n";
$body .= "Volunteer details?: ";
$body .= $vdetails;
$body .= "r\n";
$body .= "In which area?: ";
$body .= $designation;
$body .= "r\n";
$body .= "Message: ";
$body .= $message;
$body .= "r\n";

// validation
$validationOK=true;
if (!$validationOK) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
    exit;
}

// send email 
$success = mail($EmailTo, $subject, $body, "From: <$EmailFrom>");

// redirect to success page 
if ($success){
header("Location: ../Thank-You.php");
}
else{
header("Location: ../error.html");
}
?>