<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->
<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>THE YOUTH APPROACH INITIATIVE  |  MEDICAL ASSURANCE PROGRAM (MHAP)</title>
  <meta name="keywords" content="The Youth Approach Medical Assurance Program (MHAP)">
<meta name="description" content="The YAI is a Non-Profit, non-government organization operating at the grassroot level, serving humanity with an objective of helping people Stay Safe, healthy and living well">
  
<meta property="og:title" content="The Youth Approach Medical Assurance Program (MHAP)">
<meta property="og:description" content="This is a Medical Health Assurance Program of The Youth Approach Initiative (The YAI), in which every family deposits and saves a smallest affordable money with a nearest, identified Community Medical Centre for treatment at any time">
<meta property="og:image" content="http://theyouthapproachintiative.org/img/Membership-Cards.png" />
<link rel="canonical" href="http://theyouthapproachintiative.org/Program-Living-Well-Medical-Health-Assurance.php">
<link rel="shortlink" href="http://theyouthapproachintiative.org/">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">
  <style type="text/css">
  .not-ie body .container .row .span9 .row .span8 .post-d-info h3 strong a {
	color: #0080FF;
}
  </style>

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
  <!-- Header -->
  <header id="header">
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
        <div class="span3">
            
        </div>
        <img src="img/yai_banner.jpg" alt="banner">
<div class="span9">
        <div class="row space20"></div>
             <nav id="nav" role="navigation" name="nav">
               	<a href="#nav" title="Show navigation">Show navigation</a>
	            <a href="#" title="Hide navigation">Hide navigation</a>
	            <ul class="clearfix">
	           	<li><a href="index.php" title=""><span><strong>HOME</strong></span></a>
  			      <ul> <!-- Submenu -->
            <li><a href="Gallery-Videos.php" title="" target="_blank">Videos Gallery</a></li>
                      <li><a href="Gallery-Photos.php" title="">Photos Gallery</a></li>
  		         </ul> <!-- End Submenu -->
                <li><a href="About-us-info.php" title=""><span><strong>ABOUT US</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Who-we-are.php" title="">Who We Are</a></li>
                      <li><a href="Background.php" title="">Our Background</a></li>
                      <li><a href="What-we-do.php" title="">What we do</a></li>
                      <li><a href="Mission.php" title="">Our Mission</a></li>
                      <li><a href="Vision.php" title="">Our Vision</a></li>
                      <li><a href="Objectives.php" title="">Our Objectives</a></li>
                      <li><a href="Policies.php" title="">Our Policies</a></li>
                      <li><a href="Values.php" title="">Our Values</a></li>
  		         </ul> <!-- End Submenu -->
                 <li class="active"><a href="Programs-Listing.php" title=""><span><strong>OUR PROGRAMS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Program-Staying-Safe.php" title="">Staying Safe</a></li>
                    <li><a href="Program-Staying-Healthy.php" title="">Staying Healthy</a></li>
                  <li class="active"><a href="Program-Living-Well.php" title="">Living Well/ Good</a></li>
                   <li><a href="Program-Education.php" title="">Education</a></li>
                  <li><a href="Program-Cultural-Exchange.php" title="">Cultural Exchange</a></li>
                    <li><a href="Program-TheYAI-Aid.php" title="">The Youth Approach Aid</a></li>
                      <li><a href="Resources.php" title="">Youth Resources</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Projects-Listing.php" title=""><span><strong>OUR PROJECTS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Project-Stay-Safe-and-Healthy-Tours.php" title="">The Stay safe & Healthy Tours</a></li>
                      <li><a href="Project-The-Youth-Empowerment-Forum.php" title="">The Empowerment Forum</a></li>
                    <li><a href="Project-Debates-and-Dialogues.php" title="">Debates & Dialogues</a></li>
                      <li><a href="TheYAI-Aid-Agriculture.php" title="">The YAI Aid-Agriculture</a></li>
                      <li><a href="TheYAI-Aid-Education.php" title="">The YAI Aid-Education</a></li>
                      <li><a href="TheYAI-Aid-Food.php" title="">The YAI Aid-Food4Hunger</a></li>
                      <li><a href="TheYAI-Aid-Medical.php" title="">The YAI Aid-Health & Medic</a></li>
                      <li><a href="TheYAI-Aid-SACCO.php" title="">The YAI-Aid-SACCO</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Structure-Listing.php" title=""><span><strong>OUR STRUCTURES</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Structure-Governance.php" title="">Governance</a></li>
                      <li><a href="Structure-Gov-EXCOM.php" title="">The Executive Committee</a></li>
                      <li><a href="Structure-Secretariate.php" title="">The Secretariat</a></li>
                      <li><a href="Structure-Accountability.php" title="">Accountability</a></li>
                      <li><a href="Structure-Monitoring-and-Evaluation.php" title="">Monitoring & Evaluation</a></li>
                      <li><a href="Structure-Sustainability.php" title="">Sustainability</a></li>
                      <li><a href="Structure-The-YAI-RPP.php" title="">Referral Partnership</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Get-Involved-Listing.php" title=""><span><strong>GET INVOLVED</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Get-Involved-Donate.php" title="">Donate</a></li>
                      <li><a href="Get-Involved-Fundraise.php" title="">Fundraise</a></li>
                      <li><a href="Get-Involved-Join-RPP.php" title="">Join our RPP</a></li>
                      <li><a href="Duties-Secretariate-Volunteers.php" title="">Volunteer</a></li>
                      <li><a href="Get-Involved-Contract-us.php" title="">Contract Us</a></li>
                      <li><a href="Get-Involved-Organise-Event.php" title="">Organise Event</a></li>
                      <li><a href="Get-Involved-Contact-us.php" title="">Contact Us</a></li>
  		         </ul> <!-- End Submenu -->         
               </li>
	           </ul>
          </nav>
         </div> 
      </div> 
       <div class="row space40"></div>
  </div> 
</header><!-- Header End -->
<section id="titlebar">
	<!-- Container -->
	<div class="container">
	
		<div class="eight columns">
			<h3 class="left"><strong><u>OUR MEDICAL ASSURANCE PROGRAM</u> (MHAP)</strong></h3>
		</div>
		
		<div class="eight columns">
			<nav id="breadcrumbs">
				<ul>
					<li><strong><a href="Program-Living-Well-Medical-Health-Assurance-Objective.php">The Goal & Objective of the Program</a></strong></li>
				</ul>
			</nav>
		</div>

	</div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">
        <div class="row">       

          <div class="span9a">
            <!-- Blog Detail Content --> 
            <div class="row">
              <div class="span1">

                <div class="blog-icon">                 
                </div>
                   
              </div>
              <div class="span8">
                <div class="post-d-info">
                  <h3><strong>What it is ....</strong></h3>
                  <div class="blue-dark"></div>
                  <p>This is a Medical Health Assurance Program of The Youth Approach Initiative (The YAI), in which every family  deposits and saves a smallest affordable money with a nearest, identified Community Medical Centre for treatment at any time</u></h3> <br />
This program is powered and made possible by different stakeholders under The Youth Approach Referral Partnership Program

<h3><strong>How it works</strong></h3>
   
              <h3><u>Every Family deposit only UGX. 3000 per week</u>, in good, well established and recornized Medical Centre near home or of choice</h3>
              
              <p align="justify">The deposits are made on a weekly basis throughout, regardless of if healthy, sick or not. Your account in the medical centre, nearest to you will keep track the records of your deposits, visits or treatments at all times and you will also a copy of all. When develop an illness or medical problem at any time, you will just go to that medical centre with your identification, and you will be treated free of charge, and helped out if condition is complex. <br><br />From the below show you that when you start with the weekly deposit of UGX. 3000, you will have UGX. 12,000 on your medical account at the end of the month and UGX. 144,000 at the end of the year. This money is in position to cater for your full basic treatment at the specified medical centre.
   <div class="span4">
              <div class="span6">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th><strong>DEPOSIT/ Person</strong></th>
                    <th><strong>Every Week</strong></th>
                    <th><strong>In 1 Month</strong></th>
                    <th><strong>In 1 Year</strong></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                  <td><strong>For Basic Health</strong></td>
                    <td><strong>UGX. 3,000</strong></td>
                    <td><strong>UGX. 12,000</strong></td>
                    <td><strong>UGX. 144,000</strong></td>
                  </tr>  
                  <td><strong>For Complex Health</strong></td>
                    <td><strong>UGX. 10,500</strong></td>
                    <td><strong>UGX. 42,000</strong></td>
                    <td><strong>UGX. 504,000</strong></td>
                  </tr>
                  </tr>  
                  <td><strong>Acute Conditions</strong></td>
                    <td><strong>UGX. 31,500</strong></td>
                    <td><strong>UGX. 126,000</strong></td>
                    <td><strong>UGX. 1,512,000</strong></td>
                  </tr>  
                </tbody>
              </table>
            </div>  
            </div>

<h3><strong>What this money deposited will do:</strong></h3>

<div align="justify">
  This money deposited will be used by the your chosen medical centre to mainly: <br><br /><strong>-</strong>  Purchase the basic treatment necessities <br /><strong>-</strong>  Improve the Medical Centre <br /><strong>-</strong>  Buy treatment equipment <br /><strong>-</strong>  Purchase Laboratory resaurces <br /><strong>-</strong>  Contribute to the nurses welfare<br />etc
  
</div>
<h3><strong>Security, Monitoring and Evaluation of this Program</strong></h3>

<div align="justify"><strong><u>Your Deposits Security and Protection</u></strong><br>The program has the collaboration of communities' local council heads, Uganda Police - on behalf of the government and very many civil society organizations to purposely help make sure this program is meeting its purpose.</div>
</p>

<div align="justify">Every participant is liable to report any deviation, mul-practice and abuse of this program to Police, law courts, Local Councils and any other involved stakeholder. <br /> <br><strong><u>Any innapproriate behaviour?</u></strong><br>Action will be taken immediately, against the culprits and will be made to refund all the money. The money will then be transfered to another fine medical centre. The culprits will also serve a period in prison, and if no money is available for refund, the culprit's property that can amount to the participants shall be taken over on police order, and sold off to regain the money.</div>
</p>
<h3><strong>The advantages and Benefits of this Policy Program</strong></h3>

<div align="justify">
  <strong>-</strong>  The program is very affordable and cheap <br><strong>-</strong>  It is direct to its purpose of health, and no 2nd or 3rd parties involved <br /><strong>-</strong>  Treatment is a sure deal and a must whenever needed <br /><strong>-</strong>  No Financial stress and challenge when down <br /><strong>-</strong>  The policy is peaceful and voluntary <br /><strong>-</strong>  It is effective, effecient and covers anybody in the family <br /><strong>-</strong>  The policy will reduce overcrowding in other hospitals, like government hospitals <br /><strong>-</strong>  Access to the ready cleared treatment will reduce deaths caused by delay in treatment due to finances <br /><strong>-</strong>  The policy will help community medical centres to develop, get equiped, expand and offer reasonable health services </div>
</p>
<h3><strong>The Medical Centres Participation Qualifications</strong></h3>

<div align="justify">
  <strong>-</strong>  They must be registered and approved by the Uganda Ministry of Health <br><strong>-</strong>  These must be atleast at Health centre IV and above standard <br /><strong>-</strong>  All the employees and attendants of the centres must be qualified and approved by the ministry of Ministry of Education and Sports <br /><strong>-</strong>  They must have the license of operation <br /><strong>-</strong>  They must have been in operation for atleast 10 years <br /><strong>-</strong>  They must be free from criminal records of any kind  <br /><strong>-</strong> They must be recognized by the community around them </div>
  </p>
<h3><strong><a href="Program-Living-Well-Medical-Health-Assurance-Objective.php">Our Objective and goal of the Medical Assurance Policy Program</a></strong></h3>
<h4><strong><a href="Questions-MHAPP.php">QUESTIONS ANSWERED ABOUT THE PROGRAM</a></strong></h4>
<strong>Click heading to find out</strong>
<div align="justify"></div>
                </div>
                <div class="row space10"></div>   
              </div>
            </div>
            <!-- Blog Detail Content End --> 
          </div>

          <!-- Side Bar -->  
          <div class="span3">
              
            <h3 class="p-t-0">Search</h3>
            <div class="search-box">
              <a href="#" class="search-icon"><i class="icon-search"></i></a>
              <input class="search">
            </div>  

            <h3>The YAI RPP Recorgnized <u><strong>Medical Centres</strong></u></h3>
            <ul class="list-c">
              <li><i class="icon-chevron-right"></i><a href="#"><strong>EXAMPLE</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="#"><strong>Malcom Medical Center</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="#"><strong>Nsambya Hospital</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="#"><strong>KCCA Healthy Centre</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="#"><strong>Dr. Bulamu Medical Center</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="#"><strong>More Coming</strong></a></li>
            </ul> 
            </div>
<hr>

            <h3><strong>Thank You !</strong></h3>
            <div align="justify">We appreciate you coming here to our website and find out more information. It is our pleasure to offer you this service freely and hope you have been able to benefit a lot from it. We recommend you to share it with your friends and any other persons that you feel, it could be of help to them. You can also recommend them to our website here or even on our social pages like facebook, twitter, linkedin, Youtube (with a variety of videos there). Feel free to contact us for any inquiry at any time, we shall gladly get back to you. </div>
            <div class="row space10"></div>
             
 <div class="row space20"></div>
  
          <div class="row">
            <div class="span6">
              <h3><strong>Join us  |   Support us   |   Get Involved</strong></h3>
            </div>
            <div class="span6">
              <h3><u><strong>WHAT YOUR SUPPORT DOES</strong></u></h3>
            </div>
          </div>
          
          <div class="row">
            <div class="span6">
  
              <!-- Accordion -->
              <div class="accordion" id="accordion2">
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                      Donate
                    </a>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse in">
                    <div class="accordion-inner">
                      <div align="justify">Our Activities and projects are positively transforming 1000s of youths lifes in Uganda. We need your donations to sustain, maintain and push our activities further deep in the villages. Please make a donation to us today. </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                      Fundraise
                    </a>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse">
                    <div class="accordion-inner">
                      <div align="justify">Fundraises in any applicable medium do a big positive impact. We shall work hand in hand with you on this matter. </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                      0% interest Loans with NO Ts & Cs
                    </a>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse">
                    <div class="accordion-inner">
                    We utilise loans. We are an organisation, we value our work and highly committed to our image. Refunding is guaranteed. Agreements are fulfilled. However, the loans have to be free from Terms & Conditions</div>
                  </div>
                </div>
              </div>
              <!-- Accordion End -->
          
            </div>
            <div class="span6">
          
           <!-- Tabs -->
            <div class="tabbable">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#tab1" data-toggle="tab">Donations</a></li>
                <li><a href="#tab2" data-toggle="tab">Fundraises</a></li>
                <li><a href="#tab3" data-toggle="tab">Loans</a></li>
                <li><a href="#tab4" data-toggle="tab">Become a Member</a></li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane active" id="tab1">
                  <h3>Donations</h3>
                  <p align="justify">All our numerous projects involve a lot of resaurces that we sometimes fail to  meet. Your donation can help us very effectively in acquiring any required necessities to accomplish short term goals. We welcome your help</p>
                </div>
                <div class="tab-pane" id="tab2">
                  <h3>Fundraises</h3>
                  <p>Fundraises are a very effective medium of supporting us, and the they can sometimes be financially or materially. Please get intouch with us for guidelines, resaurces and all the necessary help you need to conduct one successfully. <a href="contact.htm">(Contact Us)</a></p>
                </div>
                <div class="tab-pane" id="tab3">
                  <h3>Loans</h3>
                  <p align="justify">Loans are very quick for us to acquire and help us very effectively in acquiring any required necessities to accomplish short term goals. They boost us and with no inteest, are easy for us to refund. We welcome your help. Get intouch with us for details</p>
                </div>
                <div class="tab-pane" id="tab4">
                  <h3>Participating</h3>
                  <p align="justify">Joining & becoming a member is open to all and it can be as ordinary, Active, Volunteer and Associate Membership. Your participation can also vary but the active members do huge transformations in the youth; as they encourage, strengthen and motivate them. This contributes a lot to helping them stay safe, healthy and live well.</p>
                </div>
              </div>
            </div>
            <!-- Tabs End -->           
          <div class="row space20"></div>  
        </div>
      </div>
    </div>
  </div>
  <!-- Content End -->
  
<!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="span5">
        <h3>Contact Us</h3>
        <div>         
          <form class="form-main" name="ajax-form" id="ajax-form" action="sendresults.php" method="post">
            <div id="ajaxsuccess">E-mail was successfully sent.</div> 
            <div class="error" id="err-name">Please enter name</div>
            <input name="name" id="name" type="text" value="Name" onfocus="if(this.value == 'Name') this.value='';" onblur="if(this.value == '') this.value='Name';">
            
            <div class="error" id="err-email">Please enter e-mail</div>
		        <div class="error" id="err-emailvld">E-mail is not a valid format</div>
            <input  name="email" id="email" type="text" value="E-mail" onfocus="if(this.value == 'E-mail') this.value='';" onblur="if(this.value == '') this.value='E-mail';">

            <div class="error" id="err-message">Please enter message</div>
            <textarea  name="message" id="message" type="text" value="Message"onfocus="if(this.value == 'Message') this.value='';" onblur="if(this.value == '') this.value='Message';">Message</textarea><br>
            <div>
            	<div class="error" id="err-form">There was a problem validating the form please check!</div>
            	<div class="error" id="err-timedout">The connection to the server timed out!</div>
            	<div class="error" id="err-state"></div>
            </div>
            <button id="send" class="btn f-right">Send Message <i class="icon-ok"></i></button>
          </form>
        </div>
        </div>
        <div class="span3 offset3">
          <h3>Address</h3>
          Entebbe Road, Kampala<br>
          P. O. Box 24984, Kampala (U)<br>
          KAMPALA UGANDA<br>
          <br>
          <i class="icon-phone"></i> : +256-752-848120<br>
          <i class="icon-envelope"></i>: <a href="mailto:theyouthapproach@live.com">theyouthapproach@live.com</a>			<br>
          <i class="icon-home"></i>: <a href="#" target="_blank">theyouthapproachinitiative.org</a>
          <br/><strong>JOIN US ON SOCIAL MEDIA:</strong> <br/><a href="http://www.twitter.com/theyai" target="_blank"><img src="img/Twitter.png" alt="Twitter icon" class="icon-twitter" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>
                   
<a href="http://www.facebook.com/theyouthapproachinitiative"><img src="img/facebook.png" alt="Support link to facebook Campaign" class="icon-facebook" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>     

<a href="http://www.instagram.com/theyai"><img src="img/Instagram.png" alt="link to Campaign on Instagram" class="icon-facebook" longdesc="http://http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a> 
          <div class="row space10"></div>   
          </div>
        <div class="span3 offset3">
          <h3><u>OUR WEBSITE CONTENT POLICY</u></h3>
          <div align="justify">All the information given here is correct at the time of publication.<br>
          It is in our policy to constantly update our site but we shall not be responsible for changes in the information published at any given time. Our Content is subject to changes and adjustments at anytime without prior notice.<br>
          </div>
          </div>
      </div>
      
      <div class="row space20"></div>
      <div class="row">
        <div class="span6">
          <div class="logo-footer">
            Powered by: <a href="http://web.emkingmedia.com" target="_blank">Emking Web & Online Technologies inc</a>
          </div>                       
        </div>
        <div class="span6 right">
          &copy; 2020. The Youth Approach Initiative.
        </div>
      </div>

    </div>
  </footer>
  <!-- Footer End -->

  <!-- JavaScripts -->
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" defer src="js/jquery.flexslider.js"></script>
<body>
</body>
</html>