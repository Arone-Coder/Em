<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->
<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>THE YOUTH APPROACH INITIATIVE  |  Member Details</title>
  <meta name="keywords" content="Membership details of The YaI">
<meta name="description" content="We are a Non-Profit, non-government organization operating at the grassroot level, serving humanity with an objective of helping people Stay Safe, healthy and living well">
  
<meta property="og:title" content="MEET THE PEOPLE BEHIND THE YOUTH APPROACH INITIATIVE)">
<meta property="og:description" content="They chose to guide an doffer help to their fellow youths">
<meta property="og:image" content="http://theyouthapproachintiative.org/img/YAI-logo.png" />
<link rel="canonical" href="http://theyouthapproachintiative.org/Member-Details-RichardObw.php">
<link rel="shortlink" href="http://theyouthapproachintiative.org/">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="img/favicon.png" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
  <!-- Header -->
  <header id="header">
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
       <br/> <div class="span3">
            
        </div>
        <img src="img/yai_banner.jpg" alt="banner">
        
<div class="row">
<div class="row">        
<div class="span9">
        <div class="row space10"></div>
             <nav id="nav" role="navigation" name="nav">
               	<a href="#nav" title="Show navigation">Show navigation</a>
	            <a href="#" title="Hide navigation">Hide navigation</a>
	            <ul class="clearfix">
	           	<li><a href="index.php" title=""><span><strong>HOME</strong></span></a>
  			      <ul> <!-- Submenu -->
            <li><a href="Gallery-Videos.php" title="" target="_blank">Videos Gallery</a></li>
                      <li><a href="Gallery-Photos.php" title="">Photos Gallery</a></li>
  		         </ul> <!-- End Submenu -->
                <li><a href="About-us-info.php" title=""><span><strong>ABOUT US</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Who-we-are.php" title="">Who We Are</a></li>
                      <li><a href="Background.php" title="">Our Background</a></li>
                      <li><a href="What-we-do.php" title="">What we do</a></li>
                      <li><a href="Mission.php" title="">Our Mission</a></li>
                      <li><a href="Vision.php" title="">Our Vision</a></li>
                      <li><a href="Objectives.php" title="">Our Objectives</a></li>
                      <li><a href="Policies.php" title="">Our Policies</a></li>
                      <li><a href="Values.php" title="">Our Values</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Programs-Listing.php" title=""><span><strong>OUR PROGRAMS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Program-Staying-Safe.php" title="">Staying Safe</a></li>
                      <li><a href="Program-Staying-Healthy.php" title="">Staying Healthy</a></li>
                      <li><a href="Program-Living-Well.php" title="">Living Well/ Good</a></li>
                      <li><a href="Program-Education.php" title="">Education</a></li>
                    <li><a href="Program-Cultural-Exchange.php" title="">Cultural Exchange</a></li>
                    <li><a href="Program-TheYAI-Aid.php" title="">The Youth Approach Aid</a></li>
                      <li><a href="Resources.php" title="">Youth Resources</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Projects-Listing.php" title=""><span><strong>OUR PROJECTS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Project-Stay-Safe-and-Healthy-Tours.php" title="">The Stay safe & Healthy Tours</a></li>
                      <li><a href="Project-The-Youth-Empowerment-Forum.php" title="">The Empowerment Forum</a></li>
                    <li><a href="Project-Debates-and-Dialogues.php" title="">Debates & Dialogues</a></li>
                      <li><a href="TheYAI-Aid-Agriculture.php" title="">The YAI Aid-Agriculture</a></li>
                      <li><a href="TheYAI-Aid-Education.php" title="">The YAI Aid-Education</a></li>
                      <li><a href="TheYAI-Aid-Food.php" title="">The YAI Aid-Food4Hunger</a></li>
                      <li><a href="TheYAI-Aid-Medical.php" title="">The YAI Aid-Health & Medic</a></li>
                      <li><a href="TheYAI-Aid-SACCO.php" title="">The YAI-Aid-SACCO</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li class="active"><a href="Structure-Listing.php" title=""><span><strong>OUR STRUCTURES</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Structure-Governance.php" title="">Governance</a></li>
                      <li class="active"><a href="Structure-Gov-EXCOM.php" title="">The Executive Committee</a></li>
                      <li><a href="Structure-Secretariate.php" title="">The Secretariat</a></li>
                      <li><a href="Structure-Accountability.php" title="">Accountability</a></li>
                      <li><a href="Structure-Monitoring-and-Evaluation.php" title="">Monitoring & Evaluation</a></li>
                      <li><a href="Structure-Sustainability.php" title="">Sustainability</a></li>
                      <li><a href="Structure-The-YAI-RPP.php" title="">Referral Partnership</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Get-Involved-Listing.php" title=""><span><strong>GET INVOLVED</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Get-Involved-Donate.php" title="">Donate</a></li>
                      <li><a href="Get-Involved-Fundraise.php" title="">Fundraise</a></li>
                      <li><a href="Get-Involved-Join-RPP.php" title="">Join our RPP</a></li>
                      <li><a href="Duties-Secretariate-Volunteers.php" title="">Volunteer</a></li>
                      <li><a href="Get-Involved-Contract-us.php" title="">Contract Us</a></li>
                      <li><a href="Get-Involved-Organise-Event.php" title="">Organise Event</a></li>
                      <li><a href="Get-Involved-Contact-us.php" title="">Contact Us</a></li>
  		         </ul> <!-- End Submenu --> 
               </li> 
	           </ul>
          </nav>
         </div> 
         </div> 
      </div>  
       <div class="row space40"></div>
  </div> 
</header><!-- Header End -->
<section id="titlebar">
	<!-- Container -->
	<div class="container">
	
		<div class="eight columns">
			<h3 class="left"><strong><u>About The YAI Board Members</u> </strong></h3>
		</div>
		
		<div class="eight columns">
	</div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">
        <div class="row">
          <div class="span12">
          </div>        

          <div class="span9a">
            <!-- Blog Detail Content --> 
            <div class="row">
              <div class="span1">

                <div class="blog-icon">                 
                </div>
                   
              </div>
              <div class="span8">
                <div class="post-d-info">
                  <div class="blue-dark"></div>

            <h6><strong>Mr. Richard Obwaletum, Board Member</strong></h6>
              
                </div>
                 <ul class="slides">
              <li>
                <div class="row">
<div class="span3 square-1">
                    <div class="img-container">
                      <img src="img/Our-Team/Obwaletum.png" alt="">
                      <div class="img-bg-icon"></div>
                    </div> <br/>Mr. Richard Obwaletum  
                  </div>
                  
                  <div class="span4">
                      <div class="accordion-inner">
                        <P align="justify">Mr. Richard Obwaletum is a professional Nutritionist and teacher. He holds  a degree in Food & Nutrition. He has taught and been Sports House leader, at at Nabisunsa Girls School, (one of Uganda's top schools that offers secondary school education to girls only) from 2014 - 2018, He has also been Head Coach and fitness instructor, at Sky Way Football Academy – Chongqang, China from 2018 - 2019</P>
                        <div class="img-bg-icon"></div>
                      </div>
                      </div>
                  </div> 
              </li>
            </ul>
         <p>Mr. Richard is experienced, trained and skilfully equiped with regard to life concerning the girl child. He has also been part of The Youth Approach Initiative from the very beginning of its ideology, ande has greatily contributed to the formation of The YAI and we are proud to have him on Board.</p>
         <h5 align="left"><a href="Structure-BOD.php"><strong><u>Back</strong></a> to Board Members</u></h5> 
              </div>
            </div>
            
            <!-- Blog Detail Content End --> 
          </div>

          <!-- Side Bar -->  
          <div class="span3">
              
            <h3 class="p-t-0">Find by Search</h3>
            <div class="search-box">
              <a href="#" class="search-icon"><i class="icon-search"></i></a>
              <input class="search" name="" value="Search">
            </div>  

            <h3><strong>THEIR DUTIES</strong></h3>
            <ul class="list-c">
            <h3><strong><u>The Executive Committee</u></strong></h3>
              <li><i class="icon-chevron-right"></i><a href="Duties-The-President.php"><strong>The President</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-The-VP.php"><strong>The Vice President</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-The-AGA.php"><strong>The Annual General Assembly</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Structure-Secretariate.php"><strong>The Secretariate</strong></a></li>
              
               <h3><strong><u>The Secretariate</u></strong></h3> 
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-ED.php"><strong>The Executive Director</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-GS.php"><strong>General Secretary/ Resource Manager</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-PD.php"><strong>Projects Director</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-FA.php"><strong>Financial Accountant</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-LCAR.php"><strong>Legal and constitutional affairs Representative</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-YAS.php"><strong>Youth Affairs Specialist</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-EPR.php"><strong>The YAI UG RPP Coordinator/ External Public Relations</strong></a></li>
              <li><i class="icon-chevron-right"></i><a href="Duties-EC-CMC.php"><strong>Chief Media Coordinator</strong></a></li>     
           </ul> 
            </div>
      </div>
            <h3><strong>Get in touch with us</strong></h3>
            <div>We like hearing from everyone that comes across anything to do with us. Please, it will be so grateful to hear from you. Write us a message below, and we shall get back to you as soon as we recieve your post. Thank you </div>
         <hr>
            <div class="row space10"></div>
          <div class="row">
            <div class="span6">
              <h3><strong>JOIN US    |     SUPPORT US     |    GET INVOLVED</strong></h3>
            </div>
            <div class="span6">
              <h3><u><strong>WHAT YOUR SUPPORT DOES</strong></u></h3>
            </div>
          </div>
          
          <div class="row">
            <div class="span6">
  
              <!-- Accordion -->
              <div class="accordion" id="accordion2">
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                      Donate
                    </a>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse in">
                    <div class="accordion-inner">
                      <div align="justify">Our Activities and projects are positively transforming millions of youths' lifes in Uganda. We need your donations to sustain, maintain and push our activities further deep in the villages. Please make a donation to us today. </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                      Fundraise
                    </a>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse">
                    <div class="accordion-inner">
                      <div align="justify">Fundraises in any applicable medium do a big positive impact. We shall work hand in hand with you on this matter. </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                      Contract assignments
                    </a>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse">
                    <div class="accordion-inner">
                     We are very capable of implementing projects and programs of humanitarian nature on behalf of CBOs, NGOs, CSOs & Gov't at anytime when called upon.</div>
                  </div>
                </div>
              </div>
              <!-- Accordion End -->
          
            </div>
            <div class="span6">
          
            <!-- Tabs -->
            <div class="tabbable">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#tab1" data-toggle="tab">Donations</a></li>
                <li><a href="#tab2" data-toggle="tab">Fundraises</a></li>
                <li><a href="#tab3" data-toggle="tab">Contract us</a></li>
                <li><a href="#tab4" data-toggle="tab">Volunteering</a></li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane active" id="tab1">
                  <h3>Donations</h3>
                  <p align="justify">All our numerous projects involve a lot of resaurces that we sometimes fail to  meet. Your donation can help us very effectively in acquiring any needed necessities to accomplish short term goals. We welcome your help. <a href="Get-Involved-Donate.php">(Go to Donate)</a></p>
                </div>
                <div class="tab-pane" id="tab2">
                  <h3>Fundraises</h3>
                  <p>Fundraises are a very effective medium of supporting us, and the they can sometimes be financially or materially. Please get intouch with us for guidelines, resaurces and all the necessary help you need to conduct one successfully. <a href="Get-Involved-Contact-us.php">(Contact Us)</a></p>
                </div>
                <div class="tab-pane" id="tab3">
                  <h3>Contracts</h3>
                  <p align="justify">Contracts help us utilise our capacity building program and the pay agreed upon can enable us achieve our long term goals. <a href="Get-Involved-Contact-us.php">(Contact Us)</a></p>
                  </div>
                <div class="tab-pane" id="tab4">
                  <h3>Volunteering</h3>
                  <p align="justify">We gratefully embrace working with volunteers' skills to the greatest benefit of Young People. When you contribute your energy and knowledge to us, you become one of the community’s greatest assets. You’re enveloped by a new culture, enjoy sincere hospitality, and gain valuable insight into young people’s lives, certainly. But most important, your efforts become part of the Young People’s story – directly contributing to sustained projects that help them in their future. <a href="Get-Involved-Volunteer.php">(Volunteer)</a></p>
                </div>
              </div>
            </div>
            <!-- Tabs End --> 
        </div>
      </div>
    <div align="right"><a href="#"><img src="img/Back to Top.png" alt="Back to the Top of Page" class="icon-align-right" longdesc="http://www.theyouthapproachinitiative.org"></a></div>
      <div class="space10"></div>
    </div>
  </div>
  <!-- Content End -->
  
 <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="span5">
        <h3>Contact Us</h3>
        <div>         
          <form class="form-main" name="ajax-form" id="ajax-form" action="process.php" method="post">
            <div id="ajaxsuccess">E-mail was successfully sent.</div> 
            <div class="error" id="err-name">Please enter name</div>
            <input name="name" id="name" type="text" value="Name" onfocus="if(this.value == 'Name') this.value='';" onblur="if(this.value == '') this.value='Name';">
            
            <div class="error" id="err-email">Please enter e-mail</div>
		        <div class="error" id="err-emailvld">E-mail is not a valid format</div>
            <input  name="email" id="email" type="text" value="E-mail" onfocus="if(this.value == 'E-mail') this.value='';" onblur="if(this.value == '') this.value='E-mail';">

            <div class="error" id="err-message">Please enter message</div>
            <textarea  name="message" id="message" type="text" value="Message"onfocus="if(this.value == 'Message') this.value='';" onblur="if(this.value == '') this.value='Message';">Message</textarea><br>
            <div>
            	<div class="error" id="err-form">There was a problem validating the form please check!</div>
            	<div class="error" id="err-timedout">The connection to the server timed out!</div>
            	<div class="error" id="err-state"></div>
            </div>
            <button id="send" class="btn f-right">Send Message <i class="icon-ok"></i></button>
          </form>
        </div>
        </div>
        <div class="span3 offset3">
          <h3>Address</h3>
          Entebbe Road, Kampala<br>
          P. O. Box 24984, Kampala (U)<br>
          KAMPALA UGANDA<br>
          <br>
          <i class="icon-phone"></i> : +256-752-848120<br>
          <i class="icon-envelope"></i>: <a href="mailto:theyouthapproach@live.com">theyouthapproach@live.com</a>			<br>
          <i class="icon-home"></i>: <a href="#" target="_blank">theyouthapproachinitiative.org</a>
          <br/><strong>JOIN US ON SOCIAL MEDIA:</strong> <br/><a href="http://www.twitter.com/theyai" target="_blank"><img src="img/Twitter.png" alt="Twitter icon" class="icon-twitter" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>
                   
<a href="http://www.facebook.com/theyouthapproachinitiative"><img src="img/facebook.png" alt="Support link to facebook Campaign" class="icon-facebook" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>     

<a href="http://www.instagram.com/theyai"><img src="img/Instagram.png" alt="link to Campaign on Instagram" class="icon-facebook" longdesc="http://http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a> 
          <div class="row space10"></div>   
          </div>
        <div class="span3 offset3">
          <h3><u>OUR WEBSITE CONTENT POLICY</u></h3>
          <div align="justify">All the information given here is correct at the time of publication.<br>
          It is in our policy to constantly update our site but we shall not be responsible for changes in the information published at any given time. Our Content is subject to changes and adjustments at anytime without prior notice.<br>
          </div>
          </div>
      </div>
      
      <div class="row space20"></div>
      <div class="row">
        <div class="span6">
          <div class="logo-footer">
            Powered by: <a href="http://web.emkingmedia.com" target="_blank">Emking Web & Online Technologies inc</a>
          </div>                       
        </div>
        <div class="span6 right">
          &copy; 2020. The Youth Approach Initiative.
        </div>
      </div>

    </div>
  </footer>
  <!-- Footer End -->

  <!-- JavaScripts -->
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" defer src="js/jquery.flexslider.js"></script>
<body>
</body>
</html>