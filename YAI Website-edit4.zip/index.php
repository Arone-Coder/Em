<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>THE YOUTH APPROACH INITIATIVE  |  Helps Youths and Young People Stay Safe, Healthy & Live Well; and serving humanity in Africa</title>
<head>
  <meta name="keywords" content="The Youth Approach Initiative, The YAI, Serving humanity, Youth Programs, Young People, Helping youth">
 <meta name="description" content="Our mission is helping the Youths and Young People Stay Safe, healthy & living well; and serving humans with an aim of empowerment, development & a positive achievements">
	<!-- Basic Meta Tags -->
<meta property="og:site_name" content="The Youth Approach Initiative">
<meta property="og:type" content="NGO">
<meta property="og:title" content="The Approach Initiative">
<meta property="og:description" content="Our mission is helping the Youths and Young People Stay Safe, healthy & living well; and serving humans with an aim of empowerment, development & a positive achievements">
<meta property="og:url" content="http://theyouthapproachinitiative.org">
<meta name="page-topic" content="The Approach Initiative" />
<meta property="og:locale" content="en_UG">
<meta property="og:locale" content="Uganda">
<meta property="og:image:type" content="image/png">
<meta property="og:image" content="http://theyouthapproachinitiative.org/img/YAI-logo.png">
<meta property="og:image:type" content="png">
<link rel="canonical" href="http://www.theyouthapproachinitiative.org/index.php">
<link rel="shortlink" href="http://www.theyouthapproachinitiative.org/">
<meta property="article:section" content="ngo">
<meta property="article:tag" content="helping Youths and Young People Stay Safe, Healthy & Live Well, and serving humanity">
  
    <!-- Favicon -->
  <link href="img/favicon.png" rel="icon" type="image/png">
    
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Styles -->
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
  <!-- Header -->
  <header id="header">
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
       <br/> <div class="span3">
            
        </div>
        <img src="img/yai_banner.jpg" alt="banner">
        
<div class="row">
<div class="row">        
<div class="span9">
        <div class="row space10"></div>
             <nav id="nav" role="navigation" name="nav">
               	<a href="#nav" title="Show navigation">Show navigation</a>
	            <a href="#" title="Hide navigation">Hide navigation</a>
	            <ul class="clearfix">
	           	<li class="active"><a href="index.php" title=""><span><strong>HOME</strong></span></a>
  			      <ul> <!-- Submenu -->
            <li><a href="Gallery-Videos.php" title="" target="_blank">Videos Gallery</a></li>
                      <li><a href="Gallery-Photos.php" title="">Photos Gallery</a></li>
  		         </ul> <!-- End Submenu -->
                <li><a href="About-us-info.php" title=""><span><strong>ABOUT US</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Who-we-are.php" title="">Who We Are</a></li>
                      <li><a href="Background.php" title="">Our Background</a></li>
                      <li><a href="What-we-do.php" title="">What we do</a></li>
                      <li><a href="Mission.php" title="">Our Mission</a></li>
                      <li><a href="Vision.php" title="">Our Vision</a></li>
                      <li><a href="Objectives.php" title="">Our Objectives</a></li>
                      <li><a href="Values.php" title="">Our Values</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Programs-Listing.php" title=""><span><strong>OUR PROGRAMS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Program-Staying-Safe.php" title="">Staying Safe</a></li>
                      <li><a href="Program-Staying-Healthy.php" title="">Staying Healthy</a></li>
                      <li><a href="Program-Living-Well.php" title="">Living Well/ Good</a></li>
                      <li><a href="Program-Education.php" title="">Education</a></li>
                    <li><a href="Program-Cultural-Exchange.php" title="">Cultural Exchange</a></li>
                    <li><a href="Program-TheYAI-Aid.php" title="">The Youth Approach Aid</a></li>
                      <li><a href="Resources.php" title="">Youth Resources</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Projects-Listing.php" title=""><span><strong>OUR PROJECTS</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Project-Stay-Safe-and-Healthy-Tours.php" title="">The Stay safe & Healthy Tours</a></li>
                      <li><a href="Project-The-Youth-Empowerment-Forum.php" title="">The Empowerment Forum</a></li>
                    <li><a href="Project-Debates-and-Dialogues.php" title="">Debates & Dialogues</a></li>
                      <li><a href="TheYAI-Aid-Agriculture.php" title="">The YAI Aid-Agriculture</a></li>
                      <li><a href="TheYAI-Aid-Education.php" title="">The YAI Aid-Education</a></li>
                      <li><a href="TheYAI-Aid-Food.php" title="">The YAI Aid-Food4Hunger</a></li>
                      <li><a href="TheYAI-Aid-Medical.php" title="">The YAI Aid-Health & Medic</a></li>
                      <li><a href="TheYAI-Aid-SACCO.php" title="">The YAI-Aid-SACCO</a></li>
                      <li><a href="Resources.php" title="">Youth Resources</a></li>
  		         </ul> <!-- End Submenu --> 
                 <li><a href="Structure-Listing.php" title=""><span><strong>OUR STRUCTURES</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Structure-Governance.php" title="">Governance</a></li>
                      <li><a href="Structure-Gov-EXCOM.php" title="">The Executive Committee</a></li>
                      <li><a href="Structure-Secretariate.php" title="">The Secretariate</a></li>
                      <li><a href="Structure-Accountability.php" title="">Accountability</a></li>
                      <li><a href="Structure-Monitoring-and-Evaluation.php" title="">Monitoring & Evaluation</a></li>
                      <li><a href="Structure-Sustainability.php" title="">Sustainability</a></li>
                      <li><a href="Structure-The-YAI-RPP.php" title="">Referral Partnership</a></li>
  		         </ul> <!-- End Submenu -->
                 <li><a href="Get-Involved-Listing.php" title=""><span><strong>GET INVOLVED</strong></span></a>
  			      <ul> <!-- Submenu -->
                    <li><a href="Get-Involved-Donate.php" title="">Donate</a></li>
                      <li><a href="Get-Involved-Fundraise.php" title="">Fundraise</a></li>
                      <li><a href="Get-Involved-Join-RPP.php" title="">Join our RPP</a></li>
                      <li><a href="Duties-Secretariate-Volunteers.php" title="">Volunteer</a></li>
                      <li><a href="Get-Involved-Contract-us.php" title="">Contract Us</a></li>
                      <li><a href="Get-Involved-Organise-Event.php" title="">Organise Event</a></li>
                      <li><a href="Get-Involved-Contact-us.php" title="">Contact Us</a></li>
  		         </ul> <!-- End Submenu -->  
               </li> 
	           </ul>
          </nav>
         </div> 
         </div> 
      </div> 
       <div class="row space20"></div>
          <div class="slider1 flexslider">  <!-- Slider -->
            <ul class="slides">
              <li>
    	    	    <img src="img/slider/Platforms.jpg" alt="">
    	    		</li>
    	    		<li>
    	    	    <img src="img/slider/3.jpg" alt="">
    	    		</li>
    	    		<li>
    	    	    <img src="img/slider/Enhancing voices.jpg" alt="">
    	    		</li>
                    <li>
    	    	    <img src="img/slider/4.jpg" alt="">
    	    		</li>
                    <li>
    	    	    <img src="img/slider/Hm 5.jpg" alt="">
    	    		</li>
    	    		<li>
    	    	    <img src="img/slider/Hm Pix 3.jpg" alt="">
    	    		</li>
                    <li>
    	    	    <img src="img/slider/winston.jpg" alt="">
    	    		</li>
            </ul>
          </div>  <!-- Slider End -->
  </div> 
</header>
  <!-- Header End -->
  <!-- Content -->
  <div id="content">
  <div class="row space20"></div>
    <div class="container">
       <div class="f-center">
              <h2><u>Welcome! <br />to "Helping Youths and Young People Stay Safe, Healthy & Live Well, and Serving Humanity in Africa"</u></h2>
              <div class="head-info">
                <div align="justify">Our foundation in the initial stages is based on helping the Youths and Young People Stay Safe, healthy and living well. And with observations from outbreaks like Covid-19, we got stirred up to serve any human in need on the African Continent, regardless of age, sex, religious affiliation or geo-location. Below are our holistic programs through which we are reaching out to all levels and kinds of people in communities at the grassroot level to Educate,  Encourage, Strengthen and Motivate, with an aim of empowerment, development & a postive achievement.</div>
            </div>  
       </div>
       <div class="f-hr"></div>
      <div class="row space40"></div>
      <div class="row">
        <div class="span12">
          <div class="row">
            <!-- Service Container --> 
            <div class="span4">
              <div class="ic-1"><i class="icon-lightbulb"></i></div>
              <!-- Service Title --> 
              <div class="title-1"><h4><a href="Program-Staying-Safe.php"><strong><u>STAYING SAFE</u></strong></a></h4></div>
               <div class="text-1"> 
                   through: 
                   <br /><strong>-</strong> Strengthening Focus on Education 
                   <br /><strong>-</strong> Encouraging delay for Sex involvement
                   <br /><strong>-</strong> Encouraging B & C for Partners 
                   <br /><strong>-</strong> Helping avoid early child marriage
                <br /><strong>-</strong>Women & girls' empowerment. <a href="Program-Staying-Safe.php"><br/>(Read More)</a>
              </div>
            </div>
            <!-- Service Container End --> 
            <div class="span4">
              <div class="ic-1"><i class="icon-resize-small"></i></div>
              <div class="title-1"><h4><a href="Program-Staying-Healthy.php"><strong><u>STAYING HEALTHY</u></strong></a></h4></div>
              <div class="text-1">         
                   through: 
                   <br /><strong>-</strong> Motivating Health Status checks 
                   <br /><strong>-</strong> Encouraging Stick to one your Partner 
                   <br /><strong>-</strong> Encouraging treatment for sick 
                   <br /><strong>-</strong> Mental, Psychological & Physical Rehabilitation.  
                   <br /><a href="Program-Staying-Healthy.php">(Read More)</a>
              </div>
            </div>
            <div class="span4">
              <div class="ic-1"><i class="icon-eye-open"></i></div>
              <div class="title-1"><h4><a href="Program-Living-Well.php"><strong><u>LIVING WELL/ GOOD</u></strong></a></h4></div>
              <div class="text-1">
                through: 
                <ul class="list-a"> - Economic empowerment 
                <br /><strong>-</strong>Capacity building 
                <br /><strong>-</strong>Poverty eradication
                   <br /><strong>-</strong> Motivating Dreams & Ambitions 
                <br /><strong>-</strong>Helping the youth Plan life 
                <br /><a href="Program-Living-Well.php"> (Read More)</a>
              </div>
            </div>    
          </div>
          <div class="row">
            <br/><!-- Service Container --> 
            <div class="span4">
              <div class="ic-1"><i class="icon-folder-open"></i></div>
              <!-- Service Title --> 
              <div class="title-1"><h4><a href="Program-Education.php"><strong><u>EDUCATION</u></strong></a></h4></div>
               <div class="text-1"> 
                   through: 
                   <br/><strong>-</strong> Aiding 
                   <br/><strong>-</strong> Advocating & 
                   <br/><strong>-</strong> Pushing 
                   <br/>for equal education for all youths and young people
                <br/> <a href="Program-Education.php"><br/>(Read More)</a>
              </div>
            </div>
            <!-- Service Container End --> 
            <div class="span4">
              <div class="ic-1"><i class="icon-briefcase"></i></div>
              <div class="title-1"><h4><a href="Program-TheYAI-Aid.php"><strong><u>THE YAI-AID</u></strong></a></h4></div>
              <div class="text-1">         
                   through: 
                   <br /><strong>-</strong> Plant & Animal Farming
                   <br /><strong>-</strong> Emergency food 
                   <br /><strong>-</strong> Medical Assurance 
                   <br /><strong>-</strong> Emergency Relief Response
                   <br /><strong>-</strong> Savings and Credit   
                   <br /><a href="Program-TheYAI-Aid.php">(Read More)</a>
              </div>
            </div>
            <div class="span4">
              <div class="ic-1"><i class="icon-coffee"></i></div>
              <div class="title-1"><h4><a href="Program-Cultural-Exchange.php"><strong><u>CULTURAL EXCHANGE</u></strong></a></h4></div>
              <div class="text-1">
                through: 
                <ul class="list-a"> - Intercultural learning experiences 
                <br /><strong>-</strong>Social and personal development 
                <br /><strong>-</strong>Volunteering
                   <br /><strong>-</strong> Social Sports activities 
                <br /><strong>-</strong>educational trips & exchange 
                <br /><a href="Program-Cultural-Exchange.php"> (Read More)</a>
              </div>
            </div>    
          </div>   
        </div>   
       
        <div class="span12">
          <h3><strong><u>Reaching, impacting & transforming communities</u></strong></h3>
        </div> 
        <div class="span8">        
          <img src="img/image01.png" alt="" height="280">
          <p>Our projects like Community outreaches (above) reach & touch the real targeted people</p>
        </div>
        <div class="span4">
          <div class="ic-1"></div>
          <div class="title-1"><h5><u><strong>YOUTH, KNOW ABOUT:</strong></u></h5></div>
          <!-- List -->
          <div class="text-1"> 
            <ul class="list-b">
              <!-- List Items -->
              <li><i class="icon-ok"></i> <a href="Know-About-STI-HIV-AIDS.php">STIs, HIV and AIDS</a></li>
              <li><i class="icon-ok"></i> <a href="Know-Early-Pregnancy.php">Unplanned Pregnancies</a></li>
              <li><i class="icon-ok"></i> <a href="Know-Alcoholism.php">Alcoholism in Young People</a></li>
              <li><i class="icon-ok"></i> <a href="Know-Early-Marriages.php">Unplanned early Marriages</a></li>
              <li><i class="icon-ok"></i> <a href="Know-School-drop-out.php">School Drop-outing in Young People</a></li>
              <li><i class="icon-ok"></i> <a href="Know-Social-Status.php">Youth Social Status effects</a></li>
              <li><i class="icon-ok"></i>Check in our <a href="Resources.php"><strong>Resources help</strong></a></li>
            </ul>     
          </div>
          <!-- List End -->
        </div> 
                </li>
      </div>  
            <div class="row"> 
            <div class="span6">
              <h3><strong>We engage the Young people (<a href="Gallery-Videos.php" target="_blank">Watch</a>)</strong></h3>
            
              <div class="slider2 flexslider">
                <ul class="slides">
                  <li> <a href="https://www.youtube.com/watch?v=na0tTAKSH-M" target="_blank"><img src="img/Right-Age-for-Sex.gif" alt=""></a>
               	  </li>
                  </li>
                </ul>
              </div>          
            </div>
         
            <div class="span6">
              <h3><u>Testimonies (Read below)</u></h3>
            
              <div class="slider2 flexslider">
                <ul class="slides">
                  <li>
                    <div class="testimonials">
                      "I feel so good and free wright now because there have been so many questions that i used to ask myself, and yet feared to ask anyone. You know when you think of asking your mum a personal question, she will think way beyond what you ask and as result; start suspecting you of this and that. You end up keeping quiet to yourself. But with the guys interaction here, i got free and asked everything. The guys are also very willing to respond to you & very amazingly not condemning you for this and that. To me, that was so lovely & welcoming". 
                      <br /><br />
                      <strong>Suzan Nakamya</strong> (Form 3 Student)
                    </div>
               	  </li>
                	<li>
                    <div class="testimonials">
                      "I loved every bit of this tour. It was full of fun, entertainment and yet very educative, informative and so helpful. I needed to know so much about everything regarding condoms, but without coming out to ask anyone. I feel ashamed to do such a thing, but very grateful that the peer educators tackled every information about condoms, how they work, and most importantly for me how much the different brands cost".
                      <br /><br />
                      <strong>Muhumuza</strong><br />
                      Student, Form Five
                    </div>
                	</li>
                	<li>
                    <div class="testimonials">
                      "For me personally, i just felt very good for having been given a chance to explore my talent. I made a presentation (a poem) tittled 'women not Weak Sex' That poem has been on my heart since my last holidays and presenting it has made my day. I also loved the whole arrangement, These guys understand how to deal with students, young people in general. They create an environment that frees you up". 
                      <br /><br />
                      <strong>Masaba Jacob</strong><br />
                      
                    </div>
                  </li>
                	<li>
                    <div class="testimonials">
                      "I was so much had my interest in those guys from Mulago Paramedical School. My dream is to work with medical and when i saw these guys from our biggest national hospital, i did not loose up on any minute as i tried to ask them everything that i managed to remember in relation to what i want to do in future and their experience in those fields". 
                      <br /><br />
                      <strong>Sarah</strong><br />
                      
                    </div>
   	    		  </li>
                </ul>
              </div>          
            </div>
          </div>
          <div class="row space30"></div>
          <div class="head-info">
                <div align="justify">Getting down to the grassroot level will help you realise an enormous number of issues that are factors, contributing and are capable of building up and making the young people very vulnerable to the major global challenges and problems. There are issues such as innadeduate education, mixed up self esteem and confidence, lack of guidance, poor economic status, unbalanced family treatment and so many social related challenges at the grassroot level. <br>Join us today, and lets do the necessary possibilities of Prevention, more than cure. </div>
      </div> 
         <div class="span12">
         
 <div class="row space20"></div>
 <!-- Our Team -->      
          <h3><u><strong>OUR STAY SAFE & HEALTHY TOUR PROJECT PICTORIAL >>(<a href="Gallery-Photos.php" target="_blank">See Galleries</a>)</strong></u></h3>
                
          <div  class="slider2 team flexslider">
            <ul class="slides">
              <li>
                <div class="row">
                                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (9).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>The Stay Safe & Healthy Tour</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/3. What-We-do/Empowerment.png" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>The Young People's Empowerment</h6> </div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/1. Home Page/DSC_0303.JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>The Youth & Young People's Forums</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/1. Home Page/DSC_0258.JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Young People's Talent Exhibition</h6> </div>
                  
                </div> 
              </li>
              <li>
                <div class="row">
                
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/1. Home Page/DSC_0520.JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Platform for everyone</h6> </div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (12).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Fashion & Styles Explore</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/Campus-Forum/Campus.fw.png" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>The Campus Forum (Peer)</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (21).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Talents Explored</h6> </div>
                  
                </div> 
              </li>
              <li>
                <div class="row">
                
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/A (1).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>All given the platform</h6> </div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/DSCF9481.JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Opinionated discussions</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/DSC_0255.JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Motivated Participation</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (3).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Talents & Entertainment</h6> </div>
                  
                </div> 
              </li>
              <li>
                <div class="row">
                
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (31).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Talent Exhibition platform</h6> </div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (1).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Talent explore platform</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/TSSSHT/TSSHT (5).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Guest Performances</h6></div>
                  
                  
                    <div class="span3 square-1">
                      <div class="img-container">
                        <img src="img/1. Home Page/TSSHT (30).JPG" alt="">
                        <div class="img-bg-icon"></div>
                      </div>
                      <h6>Talent explore platform</h6> </div>
                </div> 
              </li>
            </ul>
          </div>
          <!-- Our Team End -->
          </li>
           </ul>
      </div>  
             
  <div class="span12">
          <h2><u>JOIN</u> & BE PART OF <u>OUR CAMPAIGNS</u> FOR YOU AND EVERYONE</h2>
      </div> 
    
          <div class="row">
            <div class="span4"> 
              <h3><strong><u>Equal access to life essentials & services</u></strong></h3>
              <ul class="list-a">
               <li></i>Finances</li>
                <li></i>Life basic</li>
                <li></i>Education</li>
                <p><a href="#">Read more</a></p>
              </ul>   
            </div>
   
            <div class="span4"> 
              <h3><strong><u>Together for life</u></strong></h3>
              <ul class="list-a">
                <li>Peace of governments</li>
                <li>Peace in People</li>
                <li>Mutual understanding</li>
                <p><a href="#">Read more</a></p>
              </ul>   
            </div>
            
            <div class="span4"> 
              <h3><strong><u>Empowerment</u></strong></h3>
              <ul class="list-a">
                <li>Against discrimination of any kind</li>
                <li>Domestic Violence, oppression and Abuse</li>
                <p><a href="#">Read more</a></p>
              </ul>   
            </div>  
      </div>
            <div class="row space10"></div>
            
                    
          <hr>
            <h3><strong>Get in touch with us</strong></h3>
            <div>We like hearing from everyone that comes across anything to do with us. Please, it will be so grateful to hear from you. Write us a message below, and we shall get back to you as soon as we recieve your post. Thank you </div>
            
          <div class="row space10"></div>
          <div class="row">
            <div class="span6">
              <h3><strong>JOIN US    |     SUPPORT US     |    GET INVOLVED</strong></h3>
            </div>
            <div class="span6">
              <h3><u><strong>WHAT YOUR SUPPORT DOES</strong></u></h3>
            </div>
          </div>
          
          <div class="row">
            <div class="span6">
  
              <!-- Accordion -->
              <div class="accordion" id="accordion2">
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                      Donate
                    </a>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse in">
                    <div class="accordion-inner">
                      <div align="justify">Our Activities and projects are positively transforming millions of youths' lifes in Uganda. We need your donations to sustain, maintain and push our activities further deep in the villages. Please make a donation to us today. </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                      Fundraise
                    </a>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse">
                    <div class="accordion-inner">
                      <div align="justify">Fundraises in any applicable medium do a big positive impact. We shall work hand in hand with you on this matter. </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                      Contract assignments
                    </a>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse">
                    <div class="accordion-inner">
                     We are very capable of implementing projects and programs of humanitarian nature on behalf of CBOs, NGOs, CSOs & Gov't at anytime when called upon.</div>
                  </div>
                </div>
              </div>
              <!-- Accordion End -->
          
            </div>
            <div class="span6">
          
            <!-- Tabs -->
            <div class="tabbable">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#tab1" data-toggle="tab">Donations</a></li>
                <li><a href="#tab2" data-toggle="tab">Fundraises</a></li>
                <li><a href="#tab3" data-toggle="tab">Contract us</a></li>
                <li><a href="#tab4" data-toggle="tab">Volunteering</a></li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane active" id="tab1">
                  <h3>Donations</h3>
                  <p align="justify">All our numerous projects involve a lot of resaurces that we sometimes fail to  meet. Your donation can help us very effectively in acquiring any needed necessities to accomplish short term goals. We welcome your help. <a href="Get-Involved-Donate.php">(Go to Donate)</a></p>
                </div>
                <div class="tab-pane" id="tab2">
                  <h3>Fundraises</h3>
                  <p>Fundraises are a very effective medium of supporting us, and the they can sometimes be financially or materially. Please get intouch with us for guidelines, resaurces and all the necessary help you need to conduct one successfully. <a href="Get-Involved-Contact-us.php">(Contact Us)</a></p>
                </div>
                <div class="tab-pane" id="tab3">
                  <h3>Contracts</h3>
                  <p align="justify">Contracts help us utilise our capacity building program and the pay agreed upon can enable us achieve our long term goals. <a href="Get-Involved-Contact-us.php">(Contact Us)</a></p>
                  </div>
                <div class="tab-pane" id="tab4">
                  <h3>Volunteering</h3>
                  <p align="justify">We gratefully embrace working with volunteers' skills to the greatest benefit of Young People. When you contribute your energy and knowledge to us, you become one of the community’s greatest assets. You’re enveloped by a new culture, enjoy sincere hospitality, and gain valuable insight into young people’s lives, certainly. But most important, your efforts become part of the Young People’s story – directly contributing to sustained projects that help them in their future. <a href="Get-Involved-Volunteer.php">(Volunteer)</a></p>
                </div>
              </div>
            </div>
            <!-- Tabs End --> 
        </div>
      </div>
    <div align="right"><a href="#"><img src="img/Back to Top.png" alt="Back to the Top of Page" class="icon-align-right" longdesc="http://www.theyouthapproachinitiative.org"></a></div>
    </div>
  <!-- Content End -->
  
 <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="span5">
        <h3>Contact Us</h3>
        <div>         
          <form class="form-main" name="ajax-form" id="ajax-form" action="process.php" method="post">
            <div id="ajaxsuccess">E-mail was successfully sent.</div> 
            <div class="error" id="err-name">Please enter name</div>
            <input name="name" id="name" type="text" value="Name" onfocus="if(this.value == 'Name') this.value='';" onblur="if(this.value == '') this.value='Name';">
            
            <div class="error" id="err-email">Please enter e-mail</div>
		        <div class="error" id="err-emailvld">E-mail is not a valid format</div>
            <input  name="email" id="email" type="text" value="E-mail" onfocus="if(this.value == 'E-mail') this.value='';" onblur="if(this.value == '') this.value='E-mail';">

            <div class="error" id="err-message">Please enter message</div>
            <textarea  name="message" id="message" type="text" value="Message"onfocus="if(this.value == 'Message') this.value='';" onblur="if(this.value == '') this.value='Message';">Message</textarea><br>
            <div>
            	<div class="error" id="err-form">There was a problem validating the form please check!</div>
            	<div class="error" id="err-timedout">The connection to the server timed out!</div>
            	<div class="error" id="err-state"></div>
            </div>
            <button id="send" class="btn f-right">Send Message <i class="icon-ok"></i></button>
          </form>
        </div>
        </div>
        <div class="span3 offset3">
          <h3>Address</h3>
          Entebbe Road, Kampala<br>
          P. O. Box 24984, Kampala (U)<br>
          KAMPALA UGANDA<br>
          <br>
          <i class="icon-phone"></i> : +256-752-848120<br>
          <i class="icon-envelope"></i>: <a href="mailto:theyouthapproach@live.com">theyouthapproach@live.com</a>			<br>
          <i class="icon-home"></i>: <a href="#" target="_blank">theyouthapproachinitiative.org</a>
          <br/><strong>JOIN US ON SOCIAL MEDIA:</strong> <br/><a href="http://www.twitter.com/theyai" target="_blank"><img src="img/Twitter.png" alt="Twitter icon" class="icon-twitter" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>
                   
<a href="http://www.facebook.com/theyouthapproachinitiative"><img src="img/facebook.png" alt="Support link to facebook Campaign" class="icon-facebook" longdesc="http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a>     

<a href="http://www.instagram.com/theyai"><img src="img/Instagram.png" alt="link to Campaign on Instagram" class="icon-facebook" longdesc="http://http://www.theyouthapproachinitiative.org/Get-Involved-Contact-us.php"></a> 
          <div class="row space10"></div>   
          </div>
        <div class="span3 offset3">
          <h3><u>OUR WEBSITE CONTENT POLICY</u></h3>
          <div align="justify">All the information given here is correct at the time of publication.<br>
          It is in our policy to constantly update our site but we shall not be responsible for changes in the information published at any given time. Our Content is subject to changes and adjustments at anytime without prior notice.<br>
          </div>
          </div>
      </div>
      
      <div class="row space20"></div>
      <div class="row">
        <div class="span6">
          <div class="logo-footer">
            Powered by: <a href="http://web.emkingmedia.com" target="_blank">Emking Web & Online Technologies inc</a>
          </div>                       
        </div>
        <div class="span6 right">
          &copy; 2020. The Youth Approach Initiative.
        </div>
      </div>

    </div>
  </footer>
  <!-- Footer End -->

  <!-- JavaScripts -->
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" defer src="js/jquery.flexslider.js"></script>
</body>
</html>