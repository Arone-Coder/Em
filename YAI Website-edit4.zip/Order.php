<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>EMKING MEDIA COMPANY   |    Ordering</title>
</head>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
<style type="text/css">
.BL {
	color: #0000FF;
}
a:hover {
	color: #C0AA29;
}
</style>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Emking Media, Media Services in Uganda, Website Designing in Uganda, Media Coverage in Uganda, Website Hosting in Uganda, Graphics and Printing in Uganda, Photography in Uganda, Events, Directory, Emking"  />
<link href="images/favicon.ico.png" rel="icon" title="Favicon"type="image/png" id="icon" />
<link rel="shortcut icon" href="http://emkingmedia.com/images/favicon.ico" type="image/ico">
<meta name="Description" content="Emking Media is a Multi-Media services and productions Company, offering Indoor and Outdoor Visual media services &amp; products for Websites, Graphics, Videography, Events &amp; Advertising." />
<meta name="robots" content="index, follow">
<meta http-equiv="cache-control" content="no-cache" />
<meta name="revisit-after" content="15 days" />
<meta name="page-topic" content="About Emking Media" />
<meta property="og:image" content="https://www.emkingmedia.com/images/Emking_Media.JPG" />
<link rel="canonical" href="http://www.emkingmedia.com/">
<link rel="shortlink" href="http://www.emkingmedia.com/">
<style type="text/css">
body {
	background-image: url(images/body-bg%20-%20Copy.jpg);
	background-color: #fff;
}
.techpc {
	text-transform: capitalize;
}
</style>
<meta name="content-language" content="En">
<meta name="twitter:card" content="summary">
<meta name="twitter:url" content="http://www.emkingmedia.com/">
<meta name="twitter:title" content="emking_media">
<meta name="twitter:description" content="Media Services and Productions">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->

</head>
<body>
	<!-- header-section-starts -->
	<div class="container">	
		<div class="news-paper">
			<div class="header">
			  <div class="msingle-grid box">
			<div class="grid-header">
            <ul>
				<li><span></span></li>
			  </ul>
			</div>
			<div class="singlepage">
							<img src="Banners/Abt (6).jpg" height="200" class="img-responsive" />
							
			  <div class="clearfix"> </div>
				</div>
              </div>
			  <div class="social-icons">
						<li><a href="https://www.facebook.com/pages/EMKING-MEDIA-INC/387106315320"><i class="twitter"></i></a></li>
						<li><a href="http://www.twitter.com/emking_media"><i class="facebook"></i></a></li>
						<li><a href="#"><i class="rss"></i></a></li>
						<li><div class="facebook"><div id="fb-root"></div>
                        <li><a href="#"><i class="twitter"></i></a></li>
						<li><a href="#"><i class="facebook"></i></a></li>
						<li><a href="#"><i class="rss"></i></a></li>
						<li><div class="facebook"><div id="fb-root"></div>
							
							<div id="fb-root"></div>
							</div></li>
							<script>(function(d, s, id) {
							  var js, fjs = d.getElementsByTagName(s)[0];
							  if (d.getElementById(id)) return;
							  js = d.createElement(s); js.id = id;
							  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
							  fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));</script>
	   						
	   						<div class="fb-like" data-href="https://www.facebook.com/pages/EMKING-MEDIA-INC/387106315320" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false"></div>
							

					</div>
					<div class="clearfix"></div>
                    <div>CALL CUSTOMER CARE: +256 750 442113<div/>
				<div class="header-right">
					<div class="top-menu">
						<ul>        
							<li><a href="index.php">Home</a></li> |  
							<li><a href="About.php">About Us</a></li> |   
							<li><a href="Contact.php">Contact Us</a></li>  |   
							<li><a id="modal_trigger" href="#modal" class="btn1">Login</a>

	<div id="modal" class="popupContainer" style="display:none;">
		<header class="popupHeader">
			<span class="header_title">Login</span>
			<span class="modal_close"><i class="fa fa-times"></i></span>
		</header>
		
		<section class="popupBody">
			<!-- Social Login -->
			<div class="social_login">
				<div class="">
					<a href="#" class="social_box fb">
						<span class="icon"><i class="fa fa-facebook"></i></span>
						<span class="icon_title">Connect with Facebook</span>
						
					</a>

					<a href="#" class="social_box google">
						<span class="icon"><i class="fa fa-google-plus"></i></span>
						<span class="icon_title">Connect with Google</span>
					</a>
				</div>

				<div class="centeredText">
					<span>Or use your Email address</span>
				</div>

				<div class="action_btns">
					<div class="one_half"><a href="#" id="login_form" class="btn">Login</a></div>
					<div class="one_half last"><a href="#" id="register_form" class="btn">Sign up</a></div>
				</div>
			</div>

			<!-- Username & Password Login form -->
			<div class="user_login">
				<form>
					<label>Email / Username</label>
					<input type="text" />
					<br />

					<label>Password</label>
					<input type="password" />
					<br />

					<div class="checkbox">
						<input id="remember" type="checkbox" />
						<label for="remember">Remember me on this computer</label>
					</div>

					<div class="action_btns">
						<div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> Back</a></div>
						<div class="one_half last"><a href="#" class="btn btn_red">Login</a></div>
					</div>
				</form>

				<a href="#" class="forgot_password">Forgot password?</a>
			</div>

			<!-- Register Form -->
			<div class="user_register">
				<form>
					<label>Full Name</label>
					<input type="text" />
					<br />

					<label>Email Address</label>
					<input type="email" />
					<br />

					<label>Password</label>
					<input type="password" />
					<br />

					<div class="checkbox">
						<input id="send_updates" type="checkbox" />
						<label for="send_updates">Send me occasional email updates</label>
					</div>

					<div class="action_btns">
						<div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> Back</a></div>
						<div class="one_half last"><a href="#" class="btn btn_red">Register</a></div>
					</div>
				</form>
			</div>
		</section>
	</div>

<script type="text/javascript">
	$("#modal_trigger").leanModal({top : 200, overlay : 0.6, closeButton: ".modal_close" });

	$(function(){
		// Calling Login Form
		$("#login_form").click(function(){
			$(".social_login").hide();
			$(".user_login").show();
			return false;
		});

		// Calling Register Form
		$("#register_form").click(function(){
			$(".social_login").hide();
			$(".user_register").show();
			$(".header_title").text('Register');
			return false;
		});

		// Going back to Social Forms
		$(".back_btn").click(function(){
			$(".user_login").hide();
			$(".user_register").hide();
			$(".social_login").show();
			$(".header_title").text('Login');
			return false;
		});

	})
</script></li> |   
							<li><a href="Gallery.php">Our Gallery</a></li>
						</ul>
					</div>
					<!---pop-up-box---->  
					<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
				  <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
					<!---//pop-up-box---->
					<div id="small-dialog1" class="mfp-hide">
						<div class="signup">
							<h3>Subscribe</h3>
							<h4>Enter Your Valid E-mail</h4>
							<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" />
							<div class="clearfix"></div>
							<input type="submit"  value="Subscribe Now"/>
						</div>
					</div>	

                  <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
				</script>	
					<div class="search">
						<form>
							<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"/>
							<input type="submit" value="">
						</form>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
		  </div>
			<span class="menu"></span>
			<div class="menu-strip">
				<ul>           
					<li><a href="Printing_Desktop.php">GRAPHICS & PRINTING</a></li>
					<li><a href="http://www.emkingmedia.com/web" target="_blank">WEBSITES-DESIGNING</a></li>
					<li><a href="Videography.php">MEDIA-COVERAGE</a></li>
					<li><a href="Advertising.php">ADVERTISE</a></li>
					<li><a href="Events.php">EVENTS-MGT</a></li>
					<li><a href="404.php">STATIONERY</a></li>
					<li><a href="Offers.php">OFFER</a></li>
                    <li><a href="http://www.emkingmedia.com/directory" target="_blank">DIRECTORY</a></li>
				</ul>
			</div><!-- script for menu -->
			<div class="clearfix">
            <div class="grids">
		<div class="grid box">
			<div class="grid-header">
            </div>
			<div class="singlepage">
							<a href="#"><img src="images/scrol_msg_red.gif" /></a>
							<div class="photos">
					 <div class="course_demo1">
								  <ul id="flexiselDemo">	
									 <li>
										<a href="#"><img src="images/Abt (4).jpg" alt="" /></a>							
									 </li>
									 <li>
										<a href="#"><img src="images/Abt (5).jpg" alt="" /></a>
								    </li>	
									 <li>
										<a href="#"><img src="images/Abt (2).jpg" alt="" /></a>
									 </li>
                                     <li>
										<a href="#"><img src="images/Abt(8).jpg" alt="" /></a>
									 </li>	
									 <li>
										<a href="#"><img src="images/Abt (6).jpg" alt="" /></a>
									 </li>	
                                     <li>
										<a href="#"><img src="images/Abt (3).jpg" alt="" /></a>
								    </li>	
									 <li>
										<a href="#"><img src="images/Abt (1).jpg" alt="" /></a>
									 </li>
									 <li>
                                     <a href="#"><img src="images/Abt(7).jpg" alt="" /></a>
									 </li>
								 </ul>
</div>
							 <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script type="text/javascript">
							 $(window).load(function() {
								$("#flexiselDemo").flexisel({
									visibleItems: 4,
									animationSpeed: 1000,
									autoPlay: true,
									autoPlaySpeed: 3000,    		
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: { 
										portrait: { 
											changePoint:480,
											visibleItems: 2
										}, 
										landscape: { 
											changePoint:640,
											visibleItems: 2
										},
										tablet: { 
											changePoint:768,
											visibleItems: 3
										}
									}
								});
								
							 });
							  </script>
<script type="text/javascript" src="js/jquery.flexisel.js"></script>
			<!-- script for menu -->
				<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			<!-- script for menu -->
			<div class="clearfix"></div>
			<div class="main-content">		
				<div class="contact-section">
					<div class="contact-section-head">
						<h3>MAKING - ORDER - FORM</h3>
					</div>
                    
                    <!-- Address Area Start -->
                    
					<div class="contact-form-bottom">
						<div class="col-md-4 contact-form">
						<form>
								<div class="contact-form-row">
									<div>
										<span>Order For:</span>
										<input type="text" class="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">
									</div>
									<div>
										<span>Specification</span>
										<input type="text" class="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">
									</div>
									<div>
										<span>Place of Delivery (Trading Center)</span>
										<input type="text" class="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">
									</div>
									<div class="clearfix"> </div>
								</div>
                                
						</form>
					</div>
                        
                        <!-- Address Area end -->
                        
                        <!-- Contact Form Start -->
                        
						<div class="col-md-4 contact-form">
						<form>
								<div class="contact-form-row">
									<div>
										<span>Quantity</span>
										<input type="text" class="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">
									</div>
									<div>
										<span>Scale/ Surface Size</span>
									  <input type="text" class="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">
									</div>
									<div>
										<span>Plot Number</span>
										<input type="text" class="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">
									
					</div>
                    <br/><!-- Contact Form end -->
                   </div>
			</div>
            <div class="contact-form-row">
						<input type="text" placeholder="Your Name" required/>
						<input type="text" placeholder="Your Email" required/>
						<input type="text" placeholder="Your Phone" required/>
						<textarea placeholder="State brief details about what you want here" ></textarea>
						<input type="submit" value="Submit" />
				   </form>
						 </div>
									<div class="clearfix"> </div>
								</div>
                         
			<br/>
            <div class="social-icons">
             JOIN US, LIKE US & CONNECT WITH US ON<br/>
             
						<li><a href="https://www.facebook.com/pages/EMKING-MEDIA-INC/387106315320" target="_blank">
                <i class="twitter"></i></a></li><li><a href="http://www.twitter.com/emking_media" target="_blank">
                <i class="facebook"></i></a></li>
						<li><a href="#"><i class="rss"></i></a></li>
                        <li><a href="#"><i class="icon"></i></a></li>
						<li><div class="facebook"><div id="fb-root">
                        <li><a href="https://www.facebook.com/pages/EMKING-MEDIA-INC/387106315320" target="_blank">
                <i class="twitter"></i></a></li>
						<li><a href="http://www.twitter.com/emking_media" target="_blank">
                <i class="facebook"></i></a></li>
						<li><a href="#"><i class="rss"></i></a></li>
				<li><div class="facebook"><div id="fb-root">
                        </div>
							
							<div id="fb-root"></div>
							</div></li>
							<script>(function(d, s, id) {
							  var js, fjs = d.getElementsByTagName(s)[0];
							  if (d.getElementById(id)) return;
							  js = d.createElement(s); js.id = id;
							  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
							  fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));</script>
	   						
	   						<div class="fb-like" data-href="https://www.facebook.com/pages/EMKING-MEDIA-INC/387106315320" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false"></div>
							

			  </div>
              
			  <div class="clearfix"></div>
            <img src="images/call.gif" height="35" class="span_66" />
            
			<div class="footer text-center">
				<div class="bottom-menu">
					<ul>                 
						<li><a href="About.php">About Us</a></li> |
						<li><a href="Printing_Desktop.php">Graphics & Printing</a></li> |
						<li><a href="http://www.emkingmedia.com/web" target="_blank">Websites</a></li> |
						<li><a href="Videography.php">Videography</a></li> |
						<li><a href="Advertising.php">Advertise</a></li> |
						<li><a href="Events.php">Events Mgt</a></li> |
					  <li><a href="#">Staionery</a></li> |
                        <li><a href="IT-&-Computer.php">IT & Computing</a></li> |
					  <li><a href="http://www.emkingmedia.com/directory" target="_blank">Directory</a></li> 					
					</ul>
                    <ul>                 
						<li><a href="Terms_of_use.php" target="_blank">Website Terms of Use</a></li> |
						<li><a href="ServicesAgreement.php" target="_blank"> Services Agreement</a></li> |
						<li><a href="Policy_Editorial.php" target="_blank">Editorial Policy</a></li> |
						<li><a href="Policy_DigitalPrivacy.php" target="_blank">Privacy Policy</a></li> |
						<li><a href="Policy_Downloads.php" target="_blank">Downloads Policy</a></li>
                        <li><a href="Policy_SocialMedia.php" target="_blank">Social Media Policy</a></li> |
						<li><a href="Policy_CopyrightClaims.php" target="_blank">Copyright Claims Policy</a></li> |
						<li><a href="Policy_Claims.php" target="_blank">Claims</a></li>  					
					</ul>
				</div>
				<div class="copyright text-center">
					<p>EMKING MEDIA &copy; 2016. All rights reserved | Powered by:  <a href="http://web.emkingmedia.com">Emking Web Technologies</a></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>